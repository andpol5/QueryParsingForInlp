#Wayne
#Javier
#Luis
#2/Oct/2015
#Introduction to Natural Languaje Processing: Task 2


from saveIntoXml_function import *

# This part does not belong to our task, I just coded it to
#have the representation struture, which is the input of our task.
class structure:
  Qnumber = []
  Query = []
  Local = []
  What = []
  What_type = []
  Geo_relation = []
  Where = []
  Lat_Long = []

#First Example addition****************************************
Rep_str = structure()
Rep_str.Qnumber.append(1)
Rep_str.Query.append('Restaurant in Beijing,China.')
Rep_str.Local.append('YES')
Rep_str.What.append('Restaurant')
Rep_str.What_type.append('Yellow Page')
Rep_str.Geo_relation.append('in')
Rep_str.Where.append('Beijing,China')
Rep_str.Lat_Long.append('40.24, 116.42')

#Second Example addition****************************************
Rep_str.Qnumber.append(5004)
Rep_str.Query.append('7 day weather welwyn garden city')
Rep_str.Local.append('YES')
Rep_str.What.append('7 day weather')
Rep_str.What_type.append('Information')
Rep_str.Geo_relation.append('')
Rep_str.Where.append('welwyn garden city')
Rep_str.Lat_Long.append('51.80, -0.20')

#Third Example addition****************************************
Rep_str.Qnumber.append(7317)
Rep_str.Query.append('ABERDEEN AIRPORT')
Rep_str.Local.append('NO')
Rep_str.What.append('')
Rep_str.What_type.append('')
Rep_str.Geo_relation.append('')
Rep_str.Where.append('')
Rep_str.Lat_Long.append('')


#===============================================================================
#Below is our Function using Rep_str (which is the Representation structure), this 
#is what I supposed to have as an Input.

saveIntoXml(Rep_str)






