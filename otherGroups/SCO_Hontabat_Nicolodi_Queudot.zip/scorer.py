#!/usr/bin/python3

import xml.etree.ElementTree as etree
import sys 
import os

'''
  Scorer 
  version: 0.2
  authors: Alex Queudot, Raoul Nicolodi, Aurélien Hontabat
  license: MIT
'''

class Scorer:
  __queries_local   = 0
  __queries_local_test = 0
  __queries_total   = 0
  __queries_correct = 0
  
  def score(self, test_data, golden_data):
    '''
    Score the precision between two datasets
    
    Keyword arguments:
    test_data -- the link to the XML file to test_data
    golden_data -- the link to the XML file containing the correct datasetDictionaries
    '''
    
    datasetDictionaries, goldenDatasetDictionaries = self.__parse(test_data, golden_data)
    self.__compare(datasetDictionaries, goldenDatasetDictionaries)
    self.printScore()

  def printScore(self):
    
    """ Prints the score to the console """
    
    try:
      precision = self.__queries_correct / self.__queries_total 
      recall = self.__queries_local_test / self.__queries_local
      F1 = (2 * precision * recall ) / (precision + recall)
      
      print('Score ===========')
      print('Precision    ', precision)
      print('Recall       ', recall)
      print('F1           ', F1)
      print('=================')
      
    except ZeroDivisionError:
      print('Error: Number of queries is 0, did you load the files correctly?')
  
  def __compare(self, queries, golden):
    '''
    Updates the score by comparing two dictionaries
    
    Keyword arguments:
    queries -- dictionary containing the queries
    golden -- dictionary containing the results
    '''
    
    keys = queries.keys()
    
    for key in keys:
      item_golden = golden[key]
      item_test   = queries[key]
      self.__queries_total    += 1
      self.__queries_correct  += self.__cmp_items(item_test, item_golden)
      if(item_golden['LOCAL'] == 'YES'):
        self.__queries_local  += 1
      if(item_test['LOCAL'] == 'YES'):
        self.__queries_local_test += 1
  
  def __cmp_items(self, item_test, item_golden):
    '''
    Compares two items from the dictionaries following the assignments 
    criteria 
    
    Keyword arguments:
    item_test -- item from the test dictionary
    item_golden -- item from the golden dictionary
    '''
    
    tags = ['LOCAL', 'WHAT', 'WHAT-TYPE', 'GEO-RELATION', 'WHERE']
    
    for tag in tags:
      if tag == "WHERE":
        if item_test[tag] and ',' in item_test[tag]:
          if item_test[tag][:item_test[tag].index(",")] != item_golden[tag][:item_golden[tag].index(",")]:
            return 0
        elif item_test[tag] != item_golden[tag]:
          return 0
      else:
        if item_test[tag] != item_golden[tag]:
          return 0
    return 1
   
     
  def __parse(self, test_data, golden_data):
    '''
    Parse the dataset and the golden dataset 
    
    Keyword arguments:
    test_data -- dictionary containing the queries
    golden_data -- dictionary containing the results
    '''
    
    tree = etree.parse(test_data)           # Normal dataset
    tree_golden = etree.parse(golden_data)  # Golden dataset

    # Parse XML files
    root = tree.getroot()
    root_golden = tree_golden.getroot()
    
    # generates two dictionaries from the XML files
    datasetDictionary = self.__buildDictionaryList(root)
    datasetGoldenDictionary = self.__buildDictionaryList(root_golden)
    
    return (datasetDictionary, datasetGoldenDictionary)
  
  
  def __buildDictionaryList(self, xmlTree):
    '''
    Builds a dictionary of dictionaries out of the dataset 
    
    Keyword arguments:
    xmlTree -- a tree generated from the XML
    '''
    
    datasetDictionary = dict()
    completeQuery = dict()
    queryno = 0
    
    for child in xmlTree:
      completeQuery[child.tag] = child.text
      
      if(child.tag == 'QUERYNO'):
        queryno = child.text
      
      if(child.tag == 'LAT-LONG'):
        #datasetList.append(completeQuery)
        datasetDictionary[queryno] = completeQuery
        completeQuery = dict()
            
    #__all_queries = len(datasetDictionary)
    return datasetDictionary

'''
Execution

pass the two files to be compared as arguments
'''
scorer = Scorer();

if(len(sys.argv) == 3):
  print('Executing Scorer as Script')
  scorer.score(sys.argv[1], sys.argv[2])
