""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
"      CorpusParser is a Class to read file xml and save the information in a matrix       "
"                                                                                          "
""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

class CorpusParser:

    """""""""  CONSTRUCTOR """""""""
    
    def __init__(self, File_name):
        if not "xml" in File_name:                
            File_name = File_name + ".xml";              
        self.filename = File_name;                       # filename contains the name of the file to be read.
                                                         # It is given when it's defined the object
        self.data   = [];

    """""""""   METHODS   """""""""
    
    def read(self):                                      # read() reads the file and save the information
                                                         # in the matrix "data".
        content = open(self.filename, "r");
        i = -1;
        for line in content:
            element = "";                                # In the file xml there are 8 different fields which
                                                         # are related to the same information, then they will
                                                         # be saved in the same row. Each row has 8 columns
                                                         # corresponding with the following fields:
            if "<QUERYNO>" in line:                      # -QUERYNO
                i = i+1;
                self.data.append([]);
                element = int(extractLine(line));
            
            if "<QUERY>" in line:                        # -QUERY
                element = extractLine(line);
            
            if "<LOCAL>" in line:                        # -LOCAL
                if extractLine(line) == "YES":
                    element = True;
                else:
                    element = False;
                
            if "<WHAT>" in line:                         # - WHAT
                element = extractLine(line);         
            
            if "<WHAT-TYPE>" in line:                    # - WHAT-TYPE
                element = extractLine(line);
            
            if "<GEO-RELATION>" in line:                 # -GEO-RELATION
                 element = extractLine(line);          
            
            if "<WHERE>" in line:                        # -WHERE
                element = extractLine(line);
            
            if "<LAT-LONG>" in line:                     # -LAT-LONG
                coords  = element = extractLine(line).split(',')
                if len(coords) > 1:
                    element = [float(coords[0]),float(coords[1])]
                else:
                    element = None;

            if "><" in line:                                   
                element = None;                         # If any field does not have any information, it is
                                                        # assigned "None".
            
            if element != "":
                self.data[i].append(element);

        return self.data;

    def lenght(self):                                   # lenght() gives a vector with the lenght of the matrix "data".
        vector_lenght = [len(self.data), len(self.data[0])];
        return vector_lenght;

    def columns(self):                                  # columns() gives the name of the field in each column.
        return [ "QUERYNO", "QUERY", "LOCAL", "WHAT",
                 "WHAT-TYPE", "GEO-RELATION", "WHERE", "LAT-LONG"];
        


def extractLine(line):               # extractLine() is out of the class. It just extract the information from a line.
    k = 0;
    element = "";
    for i in range(len(line)):
        if ( line[i]=="<" )and( element != "" ):
            break;
        if k==1:
            element = element + line[i];
        if line[i]==">":
            k = 1;
    return element;
        
##main

inF = "L:/NQ/docencia/docencia_master_IA/INLP_MAI_2015_2016/laboCase/GC_Tr_100_User.xml"        
