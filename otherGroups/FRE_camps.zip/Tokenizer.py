#!/urs/bin/python

import shlex, subprocess, os

#PRE: Exists a file with the name represented in variable "sourcePath"'s value. This file is a plain text file codified as UTF-8 format. Freeling is correctly installed in the system. Python is correctly installed and uptodate.
#POST: The result is a list of tonkens, where each token is a list of token-caracteristics.
##def Tokenize(sourcePath):
##	#This function takes the responsability to return a list containing one list for each token contained in the file -> sourcePath.
##	#Where each of the elements of this sublist are: 
##		#1-> Token (or group of tokens with single meaning; ex.: Chez_Republic, Barack_Obama, Spain, New_York);
##		#2-> Part-of-speech tag;
##		#3-> Probability
###'''''''''''''''''''''''''''''''''''''''''''''''''''
##	listoflists	= []
##	a_list		= []
##	tempFile	= 'tokens.tmp'
##	with open(sourcePath, 'rb', 0) as a, open(tempFile, 'w') as b, open(tempFile, 'r') as c:
##		command_line 	= 'analyze --outf tagged --ner -f en.cfg'
##		subprocess.call(shlex.split(command_line), stdin=a, stdout=b)
##
##		for line in c:
##			a_list = line.split()
##			if len(a_list) > 0:
##				# del a_list[1]
##				listoflists.append(a_list)
##
##	os.remove(tempFile)
##	return listoflists

def Tokenize(sourcePath):
	#This function takes the responsability to return a list containing one list for each token contained in the file -> sourcePath.
	#Where each of the elements of this sublist are: 
		#1-> Token (or group of tokens with single meaning; ex.: Chez_Republic, Barack_Obama, Spain, New_York);
		#2-> Part-of-speech tag;
		#3-> Probability
#'''''''''''''''''''''''''''''''''''''''''''''''''''
        dirFreeling = "/home/usuaris/tools/bin/"
        sourcePath = os.getcwd()+'/'+sourcePath
        listoflists	= []
        a_list		= []
        tempFile	= os.getcwd()+'/tokens.tmp'
        with open(sourcePath, 'rb', 0) as a, open(tempFile, 'w') as b, open(tempFile, 'r') as c:
                command_line 	= dirFreeling+'analyze --outlv tagged --ner -f en.cfg'
                subprocess.call(shlex.split(command_line), stdin=a, stdout=b)
                for line in c:
                        a_list = line.split()
                        if len(a_list) > 0:
                                # del a_list[1]
                                listoflists.append(a_list)
        os.remove(tempFile)
        return listoflists

dirFreeling = "/home/usuaris/tools/bin/"
command_line 	= dirFreeling+'analyze --outlv tagged --ner -f en.cfg'
sourcePath = os.getcwd()+'/source.txt'
a = open(sourcePath, 'rb', 0)
tempFile	= os.getcwd()+'/tokens.tmp'
b = open(tempFile, 'w')
c = open(tempFile, 'r')
subprocess.call(shlex.split(command_line), stdin=a, stdout=b)
a_list		= []
#'''''''''''''''''''''''''''''''''
#SCRIPT END
#'''''''''''''''''''''''''''''''''
#Main for local testing:
##sourcePath = 'source.txt'
##print Tokenize(sourcePath)

