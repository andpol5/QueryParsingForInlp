#scorer 


class Query:

	def __init__(self, queryNO, local, what, whatType, where, geoRelation):		
	    self.local = local
	    self.what = what
	    self.whatType = whatType
	    self.where = where    
	    self.geoRelation = geoRelation
	    self.queryNO = queryNO
	    
	def describe(self):
	    print self.queryNO
	    print self.local,self.what,self.whatType,self.where,self.geoRelation  
        
	

def compareQueryNO(query1, query2):
	return query1.queryNO == query2.queryNO


def compareQuery(query1, query2):
	return query1.what == query2.what and query1.whatType == query2.whatType and query1.geoRelation == query2.geoRelation and query1.where in query2.where and len(query1.where) > 0


'''
Examples:

Query 12345: Police Station in Barcelona, Spain
Query 12348: Restaurant in Paris
'''

goldenQueries = [Query("12345", True, "Police Station", "Information", "Barcelona,Spain", "in"), Query("12348", False, "Restaurant", "Yellow Page", "Paris", "in")]
examples = [Query("12345", True , "Police Station", "Information", "Barcelona", "in"), Query("12348", False, "Restaurant", "Yellow Page", "Paris", "in")]


def score(myQueries, goldQueries):
	if (len(myQueries) == len(goldQueries)):
		hits = local_hits = local_total = 0;
		total = len(myQueries);
		for i in range(0,total):
			my_query = myQueries[i];
			correct = goldQueries[i];
			if (my_query.queryNO != correct.queryNO):
				print("ERROR: query "+ str(my_query.queryNO)+ ", it does not coincide with query "+str(correct.queryNO));
			else:
				if (not correct.local):
					if (not my_query.local):
						hits += 1;					# If it is not local no further processing is needed
				elif (correct.local):
					if (compareQuery(my_query,correct)):	
						hits += 1;
						local_hits += 1;
					local_total += 1;
		precision = hits/total;
		recall = local_hits/local_total;	
		F1Score = (2*precision*recall)/(precision+recall);
		print ("Precision = ",precision, "\nRecall = ", recall, "\nF1-score =", F1Score)
	else:
		print ("ERROR: The number of queries in your output and the number of queries in golden dataset must be the same")
