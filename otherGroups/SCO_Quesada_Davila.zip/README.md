# README #

Source: scorer.py
Requirements: python 3.4.3

The file scorer.py includes a function score(myQueries, goldQueries) that
gives three different measure to evaluate the results:
· Precision = #Hits/#Queries
· Recall = #Local_Hits/#Local_Queries
· F1-score = (2*Precision*Recall)/(Precision+Recall)

It is assumed that myQueries and goldQueries are arrays of queries following
the structure of the class Query implemented in the file.

-- CRITERION OF EVALUATION METHOD --
We consider the following criterions in the evaluation process:
1) the <LOCAL> field should be the same as the answer;
2) the terms in the <WHAT> field should be the same as the answer;
3) the <WHAT-TYPE> and <GEO-RELATION> should be the same as the answer;
4) for the <WHERE> field we consider correct if the answer of the participant
is contained in the result. For example, if the result is Barcelona,Spain and 
the participant output is or Barcelona or Spain we consider this as correct.
5) the field <LAT-LONG> is ignored in this evaluation.
We have followed the evaluation criteria of the paper "Query Parsing Task for 
GEOCLEF2007 Report".

-- IMPORTANT --
The index of the queries in myQueries and goldQueries must be the same, i.e.
if queries[3] corresponds to query number 203 then goldQueries[3] must 
correspond to the result of query number 203.
